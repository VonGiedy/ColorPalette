//DOM ELEMENTS
const saveBtn = document.getElementById("save-btn");
const generateBtn = document.getElementById("generate-btn");
const startBtn = document.getElementById("start-btn");
const introContainer = document.querySelector(".intro-container");
const mainContainer = document.querySelector(".container");
const paletteContainer = document.querySelector(".palette-container");
const savedContainer = document.querySelector(".saved-container");

//STATE & INITIALIZATION
//load from local storage, or start with empty array if nothing saved
let savedPalettes = JSON.parse(localStorage.getItem("myPalettes")) || []; //list of all saved palettes stored within this list is an object with ID, name, colors(list)

init(); // Run this immediately to show any previously saved palettes

function init() {
    // Render existing palettes from storage
    savedPalettes.forEach(renderSavedPalette);
}

//EVENT LISTENERS (Below)

saveBtn.addEventListener("click", savePalette);
generateBtn.addEventListener("click", generatePalette);
startBtn.addEventListener("click", () => {
    introContainer.classList.add("hidden");
    mainContainer.classList.remove("hidden");
    mainContainer.style.animation = "fadeIn 0.5s ease-in-out";
    generatePalette(); 
});

// Main Palette Interaction (Locking & Copying) - Neil & Friends Logic
paletteContainer.addEventListener("click", (e) => {
    const target = e.target;
    const colorBox = target.closest(".color-box");

    if (!colorBox) return;

    // Handle Lock
    const lockBtn = target.closest(".lock-btn");
    if (lockBtn) {
        colorBox.classList.toggle("locked");
        if (colorBox.classList.contains("locked")) {
            lockBtn.classList.replace("fa-lock-open", "fa-lock");
            lockBtn.title = "Unlock Color";
        } else {
            lockBtn.classList.replace("fa-lock", "fa-lock-open");
            lockBtn.title = "Lock Color";
        }
        return;
    }

    // Handle Copy
    if (target.closest(".copy-btn") || target.closest(".color")) {
        const hexValue = colorBox.querySelector(".hex-value").textContent;
        const copyIcon = colorBox.querySelector(".copy-btn");

        navigator.clipboard.writeText(hexValue)
            .then(() => {
                if (copyIcon) showCopySuccess(copyIcon);
            })
            .catch((err) => console.error("Failed to copy: ", err));
    }
});

// Saved List Interaction (NEW)
savedContainer.addEventListener("click", (e) => {
    const target = e.target;
    
    const deleteBtn = target.closest(".delete-btn");//delete-btn clicked
    if (deleteBtn) {
        const item = deleteBtn.closest(".saved-palette-item");//tracks the nearest palette item
        const idToDelete = item.dataset.id;//get the ID we stored
        savedPalettes = savedPalettes.filter(palette => palette.id != idToDelete);//remove from array
        saveToLocal();//update Local Storage
        item.remove();//remove from screen
        return;
    }

    const paletteItem = target.closest(".saved-palette-item");//palette item or saved palette clicked
    if (paletteItem) {
        const colors = JSON.parse(paletteItem.dataset.colors); //converts JSON to JS object particularly a colors lists/array
        updatePaletteDisplay(colors);//displays the colors 
    }
});

//FUNCTIONS 

//Purpose: Saves a palette and make a lists of it (NEW)
function savePalette() {
    const paletteName = prompt("Enter a name for your palette:"); //
    if (!paletteName) return; 

    const colors = [];
    const colorBoxes = document.querySelectorAll(".color-box");
    
    colorBoxes.forEach((box) => {
        const hex = box.querySelector(".hex-value").textContent;
        colors.push(hex);
    });
    //creates an object with id, name, & colors(list)
    const newPalette = {  
        id: Date.now(), // Unique ID based on current time
        name: paletteName, 
        colors: colors 
    };
    savedPalettes.push(newPalette);//push or appends the object to savedPalettes
    saveToLocal();//updates the local storage by converting the updated saved palettes to JSON
    renderSavedPalette(newPalette);//displays the new palette in the saved saved lists
}

//Purpose: Creates the elements to display the new palettes in the saved lists (NEW)
function renderSavedPalette(paletteObj) { //helper
    const paletteItem = document.createElement("div");
    paletteItem.classList.add("saved-palette-item");
    
    // Store data in HTML attributes for easy access
    paletteItem.dataset.colors = JSON.stringify(paletteObj.colors);
    paletteItem.dataset.id = paletteObj.id; 

    const miniColorsHTML = paletteObj.colors
        .map(color => `<div class="mini-color" style="background-color: ${color};"></div>`)
        .join('');

    paletteItem.innerHTML = `
        <div class="saved-left-content">
            <div class="mini-palette">
                ${miniColorsHTML}
            </div>
            <span class="palette-name">${paletteObj.name}</span>
        </div>
        <button class="delete-btn">
            <i class="fas fa-trash-alt"></i>
        </button>
    `;

    savedContainer.appendChild(paletteItem); //append the created paletteItem or elements to the savedContainer
}

//Purpose: To update local storage if there are changes in savedPalettes (NEW)
function saveToLocal() { //HELPER
    localStorage.setItem("myPalettes", JSON.stringify(savedPalettes));
}

//Purpose: To generate a palette with similar hue, color, & values (Updated GUDO Logic)
function generatePalette() {
    const colorBoxes = document.querySelectorAll(".color-box"); //selects all color-boxes in a list
    const colors = []; //final colors

    const themeMode = Math.floor(Math.random() * 3);

    //Identifies colorboxes that are locked then push/append it to colors lists
    colorBoxes.forEach(box => {
        if (box.classList.contains("locked")) {
            colors.push(box.querySelector(".hex-value").innerText);
        } else {
            colors.push(null); 
        }
    });//Result example: Colors = ["#FF0000", null, null, "#00FF00", null] "null" are area where a new color should be added

    //Fills the spot or nulls by generating a color
    for (let i = 0; i < 5; i++) {
        if (colors[i] === null) { // Only generate if this spot is empty (null)
            let newColor = generateSmartColor(themeMode);

            //Identifies if there are duplicate colors by comparing the locked colors to the new generated colors. If yes, then it generate another to replace it
            while (colors.includes(newColor)) {
                console.log("Duplicate prevented!");
                newColor = generateSmartColor(themeMode);
            }
            colors[i] = newColor; //Fill the spot
        }
    }

    updatePaletteDisplay(colors);
}

//Purpose: Generates colors with similar them (Gudo + Ai Logic)
function generateSmartColor(mode) { //helper
    const letters = "0123456789ABCDEF";
    
    // A tiny helper to pick a random 2-digit Hex (e.g., "A4" or "3B")
    const getPair = () => {
        return letters[Math.floor(Math.random() * 16)] + letters[Math.floor(Math.random() * 16)];
    };

    let r = getPair();
    let g = getPair();
    let b = getPair();

    // SMART LOGIC: Override one channel based on the theme!
    // This creates instant harmony.
    if (mode === 0) r = "FF";       // Force Red to max
    else if (mode === 1) g = "FF";  // Force Green to max
    else if (mode === 2) b = "FF";  // Force Blue to max
    
    return `#${r}${g}${b}`;
}

//Purpose: Displays the colors to the colorBoxes (Gudo Logic)
function updatePaletteDisplay(colors) {
    const colorBoxes = document.querySelectorAll(".color-box");
    colorBoxes.forEach((box, index) => {
        if (box.classList.contains("locked")) return;

        const color = colors[index];
        const colorDiv = box.querySelector(".color");
        const hexValue = box.querySelector(".hex-value");

        colorDiv.style.backgroundColor = color;
        hexValue.textContent = color;
    });
}

//Purpose: Icon change when sucessfully clicking a clipboard (Neil & Friends Logic)
function showCopySuccess(element){
    if (!element) return;
    element.classList.remove("fa-copy", "far"); 
    element.classList.add("fa-check", "fas"); 
    element.style.color = "#48bb78"; // Green

    setTimeout(() => {
        element.classList.remove("fa-check", "fas");
        element.classList.add("fa-copy", "far"); 
        element.style.color = "#111F35"; // Original Color
    }, 2000);
}

